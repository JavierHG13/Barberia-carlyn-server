"use strict";

const Alexa = require("ask-sdk-core");

const WelcomeDocument = require("./documents/WelcomeDocument.json");
const ServicesDocument = require("./documents/ServicesDocument.json");
const ServiceDetailDocument = require("./documents/ServiceDetailDocument.json");
const AppointmentDocument = require("./documents/AppointmentDocument.json");
const AdviceDocument = require("./documents/AdviceDocument.json");
const HelpDocument = require("./documents/HelpDocument.json");
const GoodbyeDocument = require("./documents/GoodbyeDocument.json");

const BRAND_IMAGE =
    "https://images.unsplash.com/photo-1583337130417-3346a1be7dee?auto=format&fit=crop&w=700&q=80";
const HERO_IMAGE =
    "https://images.unsplash.com/photo-1576201836106-db1758fd1c97?auto=format&fit=crop&w=1600&q=80";
const LOCATION_IMAGE =
    "https://images.unsplash.com/photo-1606425271394-c3ca9aa1fc06?auto=format&fit=crop&w=1200&q=80";

const CLINIC = {
    name: "Huellitas",
    subtitle: "Clinica veterinaria y estetica para mascotas",
    studentName: "Javi",
    phone: "771 123 4567",
    address: "Avenida Siempre Viva 123, Huejutla de Reyes",
    hours: "Lunes a viernes de 9 de la manana a 7 de la noche. Sabado de 10 a 3."
};

const SERVICES = {
    bano: {
        id: "bano",
        name: "Bano y spa",
        spokenName: "bano",
        price: 120,
        duration: "45 minutos",
        image: "https://images.unsplash.com/photo-1516734212186-a967f81ad0d7?auto=format&fit=crop&w=900&q=80",
        description: "Incluye limpieza completa, shampoo suave, secado y perfume ligero.",
        idealFor: "Perros pequenos y medianos que necesitan higiene regular."
    },
    consulta: {
        id: "consulta",
        name: "Consulta veterinaria",
        spokenName: "consulta veterinaria",
        price: 250,
        duration: "30 minutos",
        image: "https://images.unsplash.com/photo-1628009368231-7bb7cfcb0def?auto=format&fit=crop&w=900&q=80",
        description: "Revision general, toma de signos, orientacion medica y plan de cuidado.",
        idealFor: "Mascotas con molestias, cambios de conducta o revision preventiva."
    },
    vacunacion: {
        id: "vacunacion",
        name: "Vacunacion",
        spokenName: "vacunacion",
        price: 350,
        duration: "20 minutos",
        image: "https://images.unsplash.com/photo-1580281658629-2bbd4c6a3e8f?auto=format&fit=crop&w=900&q=80",
        description: "Aplicacion de vacuna, revision rapida y registro del esquema.",
        idealFor: "Cachorros, adultos y mascotas con refuerzo pendiente."
    },
    estetica: {
        id: "estetica",
        name: "Estetica canina",
        spokenName: "estetica",
        price: 180,
        duration: "60 minutos",
        image: "https://images.unsplash.com/photo-1591946614720-90a587da4a36?auto=format&fit=crop&w=900&q=80",
        description: "Corte de pelo, limpieza de orejas, recorte de unas y arreglo general.",
        idealFor: "Mascotas de pelo medio o largo que requieren mantenimiento."
    },
    desparasitacion: {
        id: "desparasitacion",
        name: "Desparasitacion",
        spokenName: "desparasitacion",
        price: 150,
        duration: "15 minutos",
        image: "https://images.unsplash.com/photo-1623387641168-d9803ddd3f35?auto=format&fit=crop&w=900&q=80",
        description: "Valoracion de peso y aplicacion de desparasitante segun la mascota.",
        idealFor: "Perros y gatos con calendario preventivo pendiente."
    },
    urgencias: {
        id: "urgencias",
        name: "Orientacion de urgencias",
        spokenName: "urgencias",
        price: 500,
        duration: "Atencion prioritaria",
        image: "https://images.unsplash.com/photo-1576765608535-5f04d1e3f289?auto=format&fit=crop&w=900&q=80",
        description: "Revision inicial para casos prioritarios y canalizacion inmediata.",
        idealFor: "Heridas, vomito persistente, dificultad para respirar o accidentes."
    }
};

const TIPS = {
    perro: [
        "Mantén agua limpia disponible todo el dia.",
        "Agenda vacunas y desparasitacion segun edad y peso.",
        "Cepilla su pelaje y revisa orejas, piel y patitas cada semana."
    ],
    gato: [
        "Usa arenero limpio y separado de su zona de comida.",
        "Evita cambios bruscos de alimento para prevenir problemas digestivos.",
        "Observa si deja de comer, se esconde demasiado o cambia su forma de orinar."
    ],
    cachorro: [
        "Completa su esquema de vacunacion antes de exponerlo a lugares concurridos.",
        "Dale alimento adecuado para crecimiento y porciones pequenas.",
        "Inicia socializacion positiva y rutinas cortas de entrenamiento."
    ],
    adulto: [
        "Realiza una revision preventiva al menos una vez al ano.",
        "Cuida peso, dientes y actividad fisica diaria.",
        "Consulta al veterinario ante cambios de apetito, energia o comportamiento."
    ]
};

const COMMANDS = [
    { primaryText: "Que servicios ofrecen", secondaryText: "Muestra la lista visual de servicios." },
    { primaryText: "Cuanto cuesta vacunacion", secondaryText: "Consulta precio, duracion y detalles." },
    { primaryText: "Agenda bano para perro manana", secondaryText: "Registra una cita de practica." },
    { primaryText: "Consejos para gato", secondaryText: "Recibe cuidados basicos por mascota." },
    { primaryText: "Horarios", secondaryText: "Consulta dias y horas de atencion." }
];

function normalize(value) {
    return String(value || "")
        .trim()
        .toLowerCase()
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "");
}

function money(value) {
    return `$${Number(value).toFixed(0)} pesos`;
}

function nowText(date = new Date()) {
    return new Intl.DateTimeFormat("es-MX", {
        dateStyle: "full",
        timeStyle: "short",
        timeZone: "America/Mexico_City"
    }).format(date);
}

function getResolvedSlotId(slot) {
    try {
        const authority = slot?.resolutions?.resolutionsPerAuthority?.[0];
        if (authority?.status?.code === "ER_SUCCESS_MATCH") {
            return authority.values?.[0]?.value?.id || null;
        }
    } catch (error) {
        console.log("No se pudo resolver el slot:", error.message);
    }
    return null;
}

function getSlot(handlerInput, slotName) {
    return handlerInput.requestEnvelope.request.intent.slots?.[slotName] || null;
}

function getSlotValue(handlerInput, slotName) {
    return getSlot(handlerInput, slotName)?.value || "";
}

function resolveService(slot) {
    const resolvedId = getResolvedSlotId(slot);
    if (resolvedId && SERVICES[resolvedId]) {
        return SERVICES[resolvedId];
    }

    const spoken = normalize(slot?.value);
    if (!spoken) {
        return null;
    }

    return Object.values(SERVICES).find((service) => {
        const haystack = normalize(`${service.name} ${service.spokenName} ${service.description}`);
        return haystack.includes(spoken) || spoken.includes(normalize(service.spokenName));
    }) || null;
}

function resolvePetType(value) {
    const normalized = normalize(value);
    if (normalized.includes("gato")) return "gato";
    if (normalized.includes("cachorro")) return "cachorro";
    if (normalized.includes("adulto")) return "adulto";
    return "perro";
}

function serviceCards() {
    return Object.values(SERVICES).map((service) => ({
        ...service,
        priceText: money(service.price),
        primaryText: service.name,
        secondaryText: `${money(service.price)} - ${service.description}`
    }));
}

function commonData(extra = {}) {
    return {
        app: {
            title: CLINIC.name,
            subtitle: CLINIC.subtitle,
            logo: BRAND_IMAGE,
            hero: HERO_IMAGE,
            footerText: nowText(),
            studentName: CLINIC.studentName
        },
        ...extra
    };
}

function supportsApl(handlerInput) {
    const interfaces = handlerInput.requestEnvelope.context?.System?.device?.supportedInterfaces || {};
    return Boolean(interfaces["Alexa.Presentation.APL"]);
}

function renderApl(handlerInput, token, document, datasources) {
    if (!supportsApl(handlerInput)) {
        return;
    }

    handlerInput.responseBuilder.addDirective({
        type: "Alexa.Presentation.APL.RenderDocument",
        token,
        document,
        datasources
    });
}

const LaunchRequestHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === "LaunchRequest";
    },
    handle(handlerInput) {
        renderApl(handlerInput, "welcomeToken", WelcomeDocument, commonData({
            welcome: {
                message: "Bienvenido a Huellitas. Puedo mostrar servicios, precios, horarios, consejos de cuidado y ayudarte a registrar una cita de practica.",
                commands: COMMANDS,
                services: serviceCards().slice(0, 4)
            }
        }));

        return handlerInput.responseBuilder
            .speak("Bienvenido a Huellitas. Puedes decir que servicios ofrecen, cuanto cuesta vacunacion, o agenda bano para perro manana.")
            .reprompt("Puedes decir, que servicios ofrecen.")
            .getResponse();
    }
};

const ListServicesIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === "IntentRequest" &&
            Alexa.getIntentName(handlerInput.requestEnvelope) === "ListServicesIntent";
    },
    handle(handlerInput) {
        renderApl(handlerInput, "servicesToken", ServicesDocument, commonData({
            services: {
                title: "Servicios de Huellitas",
                subtitle: "Veterinaria, estetica y bienestar para tu mascota",
                items: serviceCards()
            }
        }));

        return handlerInput.responseBuilder
            .speak("Ofrecemos bano, consulta veterinaria, vacunacion, estetica canina, desparasitacion y orientacion de urgencias. Puedes preguntar por el precio de cualquiera.")
            .reprompt("Por ejemplo, di cuanto cuesta vacunacion.")
            .getResponse();
    }
};

const GetServiceIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === "IntentRequest" &&
            Alexa.getIntentName(handlerInput.requestEnvelope) === "GetServiceIntent";
    },
    handle(handlerInput) {
        const service = resolveService(getSlot(handlerInput, "servicio"));

        if (!service) {
            return ListServicesIntentHandler.handle(handlerInput);
        }

        const facts = [
            { primaryText: "Precio", secondaryText: money(service.price) },
            { primaryText: "Duracion", secondaryText: service.duration },
            { primaryText: "Ideal para", secondaryText: service.idealFor },
            { primaryText: "Telefono", secondaryText: CLINIC.phone }
        ];

        renderApl(handlerInput, "serviceDetailToken", ServiceDetailDocument, commonData({
            detail: {
                service: { ...service, priceText: money(service.price) },
                facts
            }
        }));

        return handlerInput.responseBuilder
            .speak(`${service.name} cuesta ${money(service.price)}. ${service.description}. Puedes decir agenda ${service.spokenName} para perro manana.`)
            .reprompt("Puedes agendar una cita de practica o consultar otro servicio.")
            .getResponse();
    }
};

const BookAppointmentIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === "IntentRequest" &&
            Alexa.getIntentName(handlerInput.requestEnvelope) === "BookAppointmentIntent";
    },
    handle(handlerInput) {
        const service = resolveService(getSlot(handlerInput, "servicio")) || SERVICES.consulta;
        const petType = getSlotValue(handlerInput, "mascota") || "mascota";
        const date = getSlotValue(handlerInput, "fecha") || "proxima fecha disponible";
        const time = getSlotValue(handlerInput, "hora") || "horario por confirmar";
        const appointmentId = `HUE-${Math.floor(1000 + Math.random() * 9000)}`;

        const facts = [
            { primaryText: "Folio", secondaryText: appointmentId },
            { primaryText: "Servicio", secondaryText: service.name },
            { primaryText: "Mascota", secondaryText: petType },
            { primaryText: "Fecha", secondaryText: date },
            { primaryText: "Hora", secondaryText: time },
            { primaryText: "Costo estimado", secondaryText: money(service.price) }
        ];

        renderApl(handlerInput, "appointmentToken", AppointmentDocument, commonData({
            appointment: {
                title: "Cita de practica registrada",
                message: "Esta cita es demostrativa. Para confirmar, llama a recepcion.",
                image: service.image,
                facts
            }
        }));

        return handlerInput.responseBuilder
            .speak(`Listo, registre una cita de practica para ${service.spokenName}, para ${petType}, en ${date}, ${time}. Tu folio es ${appointmentId}.`)
            .reprompt("Puedes consultar horarios, ubicacion o pedir ayuda.")
            .getResponse();
    }
};

const CareAdviceIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === "IntentRequest" &&
            Alexa.getIntentName(handlerInput.requestEnvelope) === "CareAdviceIntent";
    },
    handle(handlerInput) {
        const petType = resolvePetType(getSlotValue(handlerInput, "mascota"));
        const topic = getSlotValue(handlerInput, "tema") || "cuidado general";
        const tips = TIPS[petType] || TIPS.perro;
        const listItems = tips.map((tip) => ({ primaryText: tip }));

        renderApl(handlerInput, "adviceToken", AdviceDocument, commonData({
            advice: {
                title: `Consejos para ${petType}`,
                subtitle: `Tema: ${topic}`,
                image: petType === "gato"
                    ? "https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?auto=format&fit=crop&w=900&q=80"
                    : BRAND_IMAGE,
                tips: listItems
            }
        }));

        return handlerInput.responseBuilder
            .speak(`Consejos para ${petType}. ${tips.join(" ")}`)
            .reprompt("Puedes pedir consejos para gato, preguntar por servicios o agendar una cita.")
            .getResponse();
    }
};

const HoursIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === "IntentRequest" &&
            Alexa.getIntentName(handlerInput.requestEnvelope) === "HoursIntent";
    },
    handle(handlerInput) {
        renderApl(handlerInput, "hoursToken", AdviceDocument, commonData({
            advice: {
                title: "Horarios",
                subtitle: "Atencion en Huellitas",
                image: LOCATION_IMAGE,
                tips: [
                    { primaryText: CLINIC.hours },
                    { primaryText: `Telefono: ${CLINIC.phone}` },
                    { primaryText: "Para urgencias, acude directamente o llama antes de trasladarte." }
                ]
            }
        }));

        return handlerInput.responseBuilder
            .speak(`Nuestros horarios son ${CLINIC.hours}`)
            .reprompt("Puedes decir ubicacion o agendar una cita.")
            .getResponse();
    }
};

const LocationIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === "IntentRequest" &&
            Alexa.getIntentName(handlerInput.requestEnvelope) === "LocationIntent";
    },
    handle(handlerInput) {
        renderApl(handlerInput, "locationToken", AdviceDocument, commonData({
            advice: {
                title: "Ubicacion",
                subtitle: CLINIC.address,
                image: LOCATION_IMAGE,
                tips: [
                    { primaryText: `Direccion: ${CLINIC.address}` },
                    { primaryText: `Telefono: ${CLINIC.phone}` },
                    { primaryText: CLINIC.hours }
                ]
            }
        }));

        return handlerInput.responseBuilder
            .speak(`Estamos en ${CLINIC.address}. Nuestro telefono es ${CLINIC.phone}.`)
            .reprompt("Puedes preguntar por servicios o horarios.")
            .getResponse();
    }
};

const EmergencyIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === "IntentRequest" &&
            Alexa.getIntentName(handlerInput.requestEnvelope) === "EmergencyIntent";
    },
    handle(handlerInput) {
        renderApl(handlerInput, "emergencyToken", AdviceDocument, commonData({
            advice: {
                title: "Orientacion de urgencias",
                subtitle: "No sustituye una revision veterinaria",
                image: SERVICES.urgencias.image,
                tips: [
                    { primaryText: "Si hay dificultad para respirar, sangrado fuerte o accidente, acude de inmediato." },
                    { primaryText: "No automediques a tu mascota." },
                    { primaryText: `Llama a Huellitas: ${CLINIC.phone}` }
                ]
            }
        }));

        return handlerInput.responseBuilder
            .speak(`Si tu mascota tiene dificultad para respirar, sangrado fuerte o sufrio un accidente, acude de inmediato con un veterinario. Llama a Huellitas al ${CLINIC.phone}.`)
            .reprompt("Puedes decir ubicacion o servicios.")
            .getResponse();
    }
};

const HelpIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === "IntentRequest" &&
            Alexa.getIntentName(handlerInput.requestEnvelope) === "AMAZON.HelpIntent";
    },
    handle(handlerInput) {
        renderApl(handlerInput, "helpToken", HelpDocument, commonData({
            help: {
                title: "Ayuda",
                text: "Huellitas entiende servicios, precios, citas de practica, horarios, ubicacion y consejos para mascotas.",
                commands: COMMANDS
            }
        }));

        return handlerInput.responseBuilder
            .speak("Puedes decir que servicios ofrecen, cuanto cuesta bano, agenda consulta para gato manana, consejos para perro, horarios, ubicacion o salir.")
            .reprompt("Prueba diciendo, que servicios ofrecen.")
            .getResponse();
    }
};

const FallbackIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === "IntentRequest" &&
            Alexa.getIntentName(handlerInput.requestEnvelope) === "AMAZON.FallbackIntent";
    },
    handle(handlerInput) {
        return handlerInput.responseBuilder
            .speak("No entendi eso. Puedes preguntar por servicios, precios, horarios, ubicacion o consejos para mascotas.")
            .reprompt("Puedes decir, ayuda.")
            .getResponse();
    }
};

const CancelAndStopIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === "IntentRequest" &&
            ["AMAZON.CancelIntent", "AMAZON.StopIntent"].includes(Alexa.getIntentName(handlerInput.requestEnvelope));
    },
    handle(handlerInput) {
        renderApl(handlerInput, "goodbyeToken", GoodbyeDocument, commonData({
            goodbye: {
                projectName: "Huellitas",
                studentName: CLINIC.studentName,
                message: "Gracias por cuidar a tu mascota con nosotros. Te esperamos pronto."
            }
        }));

        return handlerInput.responseBuilder
            .speak("Gracias por visitar Huellitas. Te esperamos pronto.")
            .getResponse();
    }
};

const NavigateHomeHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === "IntentRequest" &&
            Alexa.getIntentName(handlerInput.requestEnvelope) === "AMAZON.NavigateHomeIntent";
    },
    handle(handlerInput) {
        return LaunchRequestHandler.handle(handlerInput);
    }
};

const ErrorHandler = {
    canHandle() {
        return true;
    },
    handle(handlerInput, error) {
        console.log(`Error manejado: ${error.message}`);
        return handlerInput.responseBuilder
            .speak("Lo siento, ocurrio un error. Intenta nuevamente o di ayuda.")
            .reprompt("Puedes decir, que servicios ofrecen.")
            .getResponse();
    }
};

exports.handler = Alexa.SkillBuilders.custom()
    .addRequestHandlers(
        LaunchRequestHandler,
        ListServicesIntentHandler,
        GetServiceIntentHandler,
        BookAppointmentIntentHandler,
        CareAdviceIntentHandler,
        HoursIntentHandler,
        LocationIntentHandler,
        EmergencyIntentHandler,
        HelpIntentHandler,
        FallbackIntentHandler,
        CancelAndStopIntentHandler,
        NavigateHomeHandler
    )
    .addErrorHandlers(ErrorHandler)
    .lambda();
